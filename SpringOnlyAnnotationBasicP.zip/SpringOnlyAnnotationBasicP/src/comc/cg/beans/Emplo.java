package comc.cg.beans;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("employee2")
public class Emplo {
	@Value("9412")
	private int employeeId;
	@Value("Tharani")
	private String empName;
	@Value("54120.41")
	private float empSal;
	@Resource(name="getAddList")
	private ArrayList< Address> empAdd;
public Emplo() {
	
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public float getEmpSal() {
	return empSal;
}
public void setEmpSal(float empSal) {
	this.empSal = empSal;
}
public ArrayList<Address> getEmpAdd() {
	return empAdd;
}
public void setEmpAdd(ArrayList<Address> empAdd) {
	this.empAdd = empAdd;
}
@Override
public String toString() {
	return "Emplo [employeeId=" + employeeId + ", empName=" + empName + ", empSal=" + empSal + ", empAdd=" + empAdd.toString()
			+ "]";
}

}
