package comc.cg.beans;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestXmlAnnotationDemo {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("CgXmlAnnotation.xml");
	IGreet igreet1=	(IGreet) context.getBean("object1");
System.out.println(igreet1.greetMe());
System.out.println("--------------------------------------");
IGreet igreet2=	(IGreet) context.getBean("object2");
System.out.println(igreet2.greetMe());
System.out.println("---------------------------------------");
Employee employee1=(Employee) context.getBean("employee1");
System.out.println(employee1);
	}

}
