package com.cg.bean;
public class NewYearGreetings implements IGreet{
	String firstName;
	int year;
	 public NewYearGreetings() {
	
		System.out.println("In New Greeeting...."+"Constructor");
	}
	public NewYearGreetings(String firstName, int year) {
		super();
		this.firstName = firstName;
		this.year = year;
		System.out.println("Inside the parameterized of New year Greeting");
	}
	public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
	System.out.println("--------------SetfirstName() is called from New year");
}
	public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
	System.out.println("------------Setyear() is called from New year");
}
	@Override
	public String greetMe() {
		
		return "Happy New Year "+firstName+"   "+year;
	}

}
