package com.cg.bean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestSpringAppContectContainerDemo {
	public static void main(String[] args) {
	ApplicationContext applicationCtxObj=new ClassPathXmlApplicationContext("cg.xml");
	System.out.println("-------Spring container was initilzaed---------");
	System.out.println("---------------Birthday wish----------");
     IGreet igreetObj1=(IGreet) applicationCtxObj.getBean("object1");
     System.out.println(igreetObj1.greetMe());
     System.out.println(igreetObj1.hashCode());
     /*IGreet igreetObj2=(IGreet) applicationCtxObj.getBean("object1");
     System.out.println(igreetObj2.greetMe());
     System.out.println(igreetObj2.hashCode());*/
     System.out.println("--------New Year wish----------");
     IGreet igreetObj3=(IGreet) applicationCtxObj.getBean("object2");
     System.out.println(igreetObj3.greetMe());
     System.out.println(igreetObj3.hashCode());
     /*IGreet igreetObj4=(IGreet) applicationCtxObj.getBean("object2");
     System.out.println(igreetObj4.greetMe());
     System.out.println(igreetObj4.hashCode());*/
     
     System.out.println("---------------Birthday wish----------");
     IGreet igreetObj4=(IGreet) applicationCtxObj.getBean("object3");
     System.out.println(igreetObj4.greetMe());
     System.out.println(igreetObj4.hashCode());
     
     
     
     System.out.println("--------New Year wish----------");
     IGreet igreetObj5=(IGreet) applicationCtxObj.getBean("object4");
     System.out.println(igreetObj5.greetMe());
     System.out.println(igreetObj5.hashCode());
	}

}
