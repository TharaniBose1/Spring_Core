package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestLifeCycle {
	public static void main(String[] args) {
		ApplicationContext applicationCtxObj=new ClassPathXmlApplicationContext("cg.xml");
		IGreet igreetObj1=(IGreet) applicationCtxObj.getBean("object1");
	     System.out.println(igreetObj1.greetMe());
	}
}
