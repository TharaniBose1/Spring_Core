package com.cg.beans;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan(basePackages="comc.cg.beans")
public class TestXmlAnnotationUserProp {
	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(TestXmlAnnotationEmployeeDemo.class, args);
   User user=(User) context.getBean("user1");
   System.out.println(user);
	}

}
