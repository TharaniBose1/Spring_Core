package com.cg.beans;
import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
@Configuration
public class SpringConfig {
	
	//Multiple Address
	@Bean
public ArrayList<Address> getAddList(){
	
	Address address1=new Address();
	address1.setCity("Madurai");
	address1.setState("Tamil Nadu");
	address1.setZipCode(625514);
	Address address2=new Address();
	address2.setCity("Chennai");
	address2.setState("Tamil Nadu");
	address2.setZipCode(125514);
	ArrayList<Address> adList=new ArrayList<>();
	adList.add(address1);
	adList.add(address2);
	return adList;
	
}
	
/*---------------------------------------------------*/
	@Bean
	public Address getOffAddress2() {
		Address ad=new Address();
		ad.setCity("Madurai");
		ad.setState("Tamil Nadu");
		ad.setZipCode(45741);
		return ad;
	}
	/*---------------------------------------------------*/
	@Bean
	public static PropertySourcesPlaceholderConfigurer
	propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
		
	}
	
}
