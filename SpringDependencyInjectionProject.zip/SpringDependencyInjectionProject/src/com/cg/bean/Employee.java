package com.cg.bean;
public class Employee {
private int employeeId;
private String empName;
private float empSal;
private Address empAdd;
public Employee() {}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public float getEmpSal() {
	return empSal;
}
public void setEmpSal(float empSal) {
	this.empSal = empSal;
}
public Address getEmpAdd() {
	return empAdd;
}
public void setEmpAdd(Address empAdd) {
	this.empAdd = empAdd;
}

}
