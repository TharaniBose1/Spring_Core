package com.cg.bean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestEmployeeDemo {
	public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("cg.xml");
	Employee employee1=(Employee) context.getBean("object1");
	System.out.println("----Emp Info------");
	System.out.println("ID :"+employee1.getEmployeeId()+"   Salary  :"+employee1.getEmpSal()+"\n"+"Address\n"+"State :"+employee1.getEmpAdd().getState()+"City with pincode :"+employee1.getEmpAdd().getCity()+","+employee1.getEmpAdd().getZipCode());
	System.out.println("------------------------------------");
	Emplo employee2=(Emplo) context.getBean("tharaniObject");
	System.out.println("----Emp Info------");
	System.out.println("ID :"+employee2.getEmployeeId()+"   Salary  :"+employee2.getEmpSal()+"\n"+"Address\n"+"State :"+employee2.getEmpAdd()); 
	}

}
