package com.cg.bean;

import java.util.ArrayList;

public class Emplo {
	private int employeeId;
	private String empName;
	private float empSal;
	private ArrayList< Address> empAdd;
public Emplo() {
	
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public float getEmpSal() {
	return empSal;
}
public void setEmpSal(float empSal) {
	this.empSal = empSal;
}
public ArrayList<Address> getEmpAdd() {
	return empAdd;
}
public void setEmpAdd(ArrayList<Address> empAdd) {
	this.empAdd = empAdd;
}

}
