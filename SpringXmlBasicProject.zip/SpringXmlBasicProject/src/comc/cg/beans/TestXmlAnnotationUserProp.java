package comc.cg.beans;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestXmlAnnotationUserProp {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("CgXmlAnnotation.xml");
   User user=(User) context.getBean("user1");
   System.out.println(user);
	}

}
