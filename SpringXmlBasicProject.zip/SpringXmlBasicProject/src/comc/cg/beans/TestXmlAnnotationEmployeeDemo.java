package comc.cg.beans;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestXmlAnnotationEmployeeDemo {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("CgXmlAnnotation.xml");
		Employee employee1=(Employee) context.getBean("employee1");
		System.out.println(employee1);
		System.out.println("--------------------------------");
		Emplo employee2=(Emplo) context.getBean("employee2");
		System.out.println(employee2);
	}

}
