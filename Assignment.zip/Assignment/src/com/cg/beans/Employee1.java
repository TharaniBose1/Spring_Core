package com.cg.beans;
import java.util.ArrayList;
import java.util.LinkedHashSet;
public class Employee1 {
	private int empId;
	private String empName;
	private float empSal;
	private LinkedHashSet<SBU1> businessUnit;
	private int empage;
	public Employee1() {}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public LinkedHashSet<SBU1> getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(LinkedHashSet<SBU1> businessUnit) {
		this.businessUnit = businessUnit;
	}
	public int getEmpage() {
		return empage;
	}
	public void setEmpage(int empage) {
		this.empage = empage;
	}
	@Override
	public String toString() {
		return "Employee Details :[empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", businessUnit="
				+ businessUnit.toString() + ", empage=" + empage + "]";
	}
	
}
