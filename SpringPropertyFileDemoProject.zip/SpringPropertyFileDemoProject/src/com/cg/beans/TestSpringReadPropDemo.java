package com.cg.beans;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestSpringReadPropDemo {
	public static void main(String[] args) {
	ApplicationContext context= new ClassPathXmlApplicationContext("cg.xml");
	User myCredentials=(User) context.getBean("user1");
	System.out.println(myCredentials);

	}

}
